bindir=`dirname "$me$0"`
libdir=`cd "${bindir}/lib" ; pwd`
LD_LIBRARY_PATH="${libdir}:${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH
cd ${bindir}
./UpdateUtility-Gui $@
